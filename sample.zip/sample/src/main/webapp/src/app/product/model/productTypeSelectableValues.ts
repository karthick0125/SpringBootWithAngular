export class ProductTypeSelectableValues {
  constructor(public productTypeName: String,
              public productType: Number) {}
}
