export class PpsrEpmMapping {

  constructor(public pref: String,
              public productFamilyName: String,
              public productGroupName: String,
              public productName: String,
              public productVariantName: String,
              public prCode: String,
              public productFriendlyId: Number) {
  }

}
