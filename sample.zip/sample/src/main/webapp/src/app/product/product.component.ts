import { PriceLineSelectableValues } from './model/priceLineSelectableValues';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { PortfolioForm } from './portfolioform';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { PortfolioService } from './portfolio.service';
import { ProductTypeSelectableValues } from './model/productTypeSelectableValues';
import { ProductNameSelectableValues } from './model/productNameSelectableValues';
import { HttpParams } from '@angular/common/http';
import { ProductFriendlyNameSelectableValues } from './model/ProductFriendlyNameSelectableValues';
import { PpsrEpmMapping } from './model/ppsrEpmMapping';
import { catchError } from 'rxjs/operators';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { BlockUI, NgBlockUI } from 'ng-block-ui';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;

  public message: String = null;
  public portfolio = new PortfolioForm(null, null, null, null, null, null, null, null);
  public searchContent: String;
  public productTypeSelectableValues: ProductTypeSelectableValues[];
  public productNameSelectableValues: ProductNameSelectableValues[];
  public productFriendlyNameSelectableValues: ProductFriendlyNameSelectableValues[];
  public pricelineNames: PriceLineSelectableValues[];
  public chargeTypes: String[];
  public revenueCodeName: String = this.portfolio.ppsrEpmMapping != null ? this.portfolio.ppsrEpmMapping.productVariantName : null;

  /*  public productTypes: ProductType[] = [
      { 'productType': 'abe', 'productKey' : 2},
      {'productType': 'cdf', 'productKey' : 2
  } ]; */

  constructor(private portfolioService: PortfolioService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.blockUI.start('Loading...');
    this.portfolioService.getProductTypes().subscribe(data => this.productTypeSelectableValues = data);
    this.portfolioService.getChargeTypes().subscribe(data => {
        this.chargeTypes = data;
        this.blockUI.stop();
      }
    );
  }

  onSubmit() {
    console.log(JSON.stringify(this.portfolio));
   // this.message = 'Form details updated successfully';
    this.blockUI.start('Updating Form Details.... Please Wait..');
    this.portfolioService.saveFormDetails(this.portfolio).subscribe(
      data => {
        this.portfolio = new PortfolioForm(null, null, null, null, null, null, null, null);
        this.message = data;
        this.blockUI.stop();
      }
    );
  }

  onProductTypeChange() {
    this.productNameSelectableValues = [];
    this.portfolio.productNameSelectableValue = null;
  }

  serachProductNames(searchContent: String) {
    console.log(searchContent, this.portfolio.productType);
    console.log(this.portfolio.productNameSelectableValue);
    this.blockUI.start('Loading Product Names.... Please Wait..');
    const params = new HttpParams().set('productType', String(this.portfolio.productType))
      .set('searchContent', `${searchContent}`);
    this.portfolioService.getProductNames(params)
      .subscribe(data => {
        this.productNameSelectableValues = data;
        this.blockUI.stop();
      }
    );
  }

  onProductNameChange() {
    console.log(this.portfolio.productNameSelectableValue);
    this.productFriendlyNameSelectableValues = [];
    this.portfolio.productFriendlyNameSelectableValue = null;
    this.blockUI.start('Loading Friendly Names.... Please Wait..');
    const params = new HttpParams().set('prodKey', String(this.portfolio.productNameSelectableValue.prodKey));
    this.portfolioService.getProductFriendlyNames(params)
      .subscribe(data => {
        this.productFriendlyNameSelectableValues = data;
        this.blockUI.stop();
      }
    );
  }

  onProductFriendNameChange() {
    console.log(this.portfolio.productFriendlyNameSelectableValue);
    this.pricelineNames = [];
    this.portfolio.priceLineSelectableValue = null;
    this.blockUI.start('Loading Price Line Details.... Please Wait..');
    const params = new HttpParams().set('prodFriendlyId', String(this.portfolio.productFriendlyNameSelectableValue.productFriendlyId));
    this.portfolioService.getPricelineNames(params)
      .subscribe(data => {
         this.pricelineNames = data;
         this.blockUI.stop();
      }
        );
  }

  fetchEpmMappingDetails() {
    const params = new HttpParams().set('pRefIds', String(this.portfolio.productCode));
    this.blockUI.start('Fetching EPM Details.... This will take few minutes.Please Wait..');
    this.portfolioService.fetchEpmMappingDetails(params)
      .subscribe(data => {
        this.portfolio.ppsrEpmMapping = data;
        this.revenueCodeName = data.productVariantName;
        this.blockUI.stop();
       });
  }

 }
