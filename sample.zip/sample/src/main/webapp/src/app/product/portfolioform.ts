import { ProductNameSelectableValues } from './model/productNameSelectableValues';
import { ProductFriendlyNameSelectableValues } from './model/ProductFriendlyNameSelectableValues';
import { PpsrEpmMapping } from './model/ppsrEpmMapping';
import { PriceLineSelectableValues } from './model/priceLineSelectableValues';

export class PortfolioForm {

  constructor(public productType: Number,
              public productNameSelectableValue: ProductNameSelectableValues,
              public productFriendlyNameSelectableValue: ProductFriendlyNameSelectableValues,
              public projectCode: String,
              public productCode: String,
              public chargeType: String,
              public ppsrEpmMapping: PpsrEpmMapping,
              public priceLineSelectableValue: PriceLineSelectableValues) {
  }

}
