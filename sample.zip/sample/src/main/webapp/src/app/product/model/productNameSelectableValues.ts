export class ProductNameSelectableValues {
  constructor(public prodKey: Number,
              public productName: String) {}
}
