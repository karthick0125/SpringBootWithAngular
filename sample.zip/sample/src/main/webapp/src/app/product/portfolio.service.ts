import { PortfolioForm } from './portfolioform';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductTypeSelectableValues } from './model/productTypeSelectableValues';
import { ProductNameSelectableValues } from './model/productNameSelectableValues';
import { ProductFriendlyNameSelectableValues } from './model/ProductFriendlyNameSelectableValues';
import { PpsrEpmMapping } from './model/ppsrEpmMapping';
import { PriceLineSelectableValues } from './model/priceLineSelectableValues';

@Injectable({
  providedIn: 'root'
})
export class PortfolioService {

  constructor(private http: HttpClient) { }

  getProductTypes(): Observable<ProductTypeSelectableValues[]> {
    return this.http.get<ProductTypeSelectableValues[]>('/ppsr/ppsr-portfolio/productTypeSelectableValues');
  }


  getChargeTypes(params?: HttpParams): Observable<String[]> {
    return this.http.get<String[]>('/ppsr/ppsr-portfolio/chargeTypeSelectableValues');
  }
  getProductNames(params?: HttpParams): Observable<ProductNameSelectableValues[]> {

    return this.http.get<ProductNameSelectableValues[]>('/ppsr/ppsr-portfolio/productNameSelectableValues',
      { params });
  }

  getProductFriendlyNames(params?: HttpParams): Observable<ProductFriendlyNameSelectableValues[]> {

    return this.http.get<ProductFriendlyNameSelectableValues[]>('/ppsr/ppsr-portfolio/productFriendlyNameSelectableValues',
      { params });
  }

  getPricelineNames(params?: HttpParams): Observable<PriceLineSelectableValues[]> {
    return this.http.get<PriceLineSelectableValues[]>('/ppsr/ppsr-portfolio/pricelineNameSelectableValues',
      { params });
  }

  fetchEpmMappingDetails(params?: HttpParams): Observable<PpsrEpmMapping> {
    return this.http.get<PpsrEpmMapping>('/ppsr/ppsr-portfolio/fetchEpmMappingDetails',
      { params });
  }
  saveFormDetails( portfolioForm: PortfolioForm): Observable<String> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };
    return this.http.post<String>('/ppsr/ppsr-portfolio/saveFormDetails', portfolioForm, httpOptions );
  }
}
