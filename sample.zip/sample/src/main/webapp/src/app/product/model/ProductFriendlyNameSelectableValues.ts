export class ProductFriendlyNameSelectableValues {
  constructor(public productFriendlyName: String,
              public productFriendlyId: Number
              ) {}
}
