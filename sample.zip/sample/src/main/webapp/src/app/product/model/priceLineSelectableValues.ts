export class PriceLineSelectableValues {
  constructor(public priceLineName: String,
              public plnDescId: Number) {}
}
