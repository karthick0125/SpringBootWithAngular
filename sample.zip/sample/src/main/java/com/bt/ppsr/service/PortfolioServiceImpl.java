package com.bt.ppsr.service;

import com.bt.ppsr.client.EpmClient;
import com.bt.ppsr.model.*;
import com.bt.ppsr.repository.PpsrRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortfolioServiceImpl implements PortfolioService {

    @Autowired
    private PpsrRepository repository;

    @Autowired
    private EpmClient epmClient;

    @Override
    public List<ProductTypeSelectableValuesDTO> getProductTypes() {
        return repository.getProductTypes();
    }

    @Override
    public List<ProductNameSelectableValuesDTO> getProductNames(Integer selectedProductType, String searchString) {
        return repository.getProductNames(selectedProductType, searchString);
    }

    @Override
    public List<ProductFriendlyNameSelectableValuesDTO> getProductFriendlyNames(Integer prodKey) {
        return repository.getProductFriendlyNames(prodKey);
    }

    @Override
    public List<PriceLineSelectableValuesDTO> getPriceLineNames(Integer prodFriendlyId) {

        return repository.getPriceLineNames(prodFriendlyId);
    }

    @Override
    public List<String> getChargeTypes() {
        return repository.getChargeTypes();
    }

    @Override
    public PpsrEpmMappingDTO fetchEpmMappingDetails(String pRefIds) {
        PpsrEpmMappingDTO ppsrEpmMappingDTO = null;
        List<PpsrEpmMappingDTO> epmDetails = epmClient.getEpmDetails(pRefIds);
        if (!epmDetails.isEmpty()) {
            ppsrEpmMappingDTO = epmDetails.get(0);
            //repository.saveEpmMappingDetails(ppsrEpmMappingDTO.toEntity());
        }
        return ppsrEpmMappingDTO;
    }


    public void savePortfolioFormDetails(PortfolioForm portfolioForm) {
        repository.savePortfolioFormDetails(portfolioForm);

    }
}
