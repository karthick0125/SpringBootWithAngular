package com.bt.ppsr.model;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class EPMProductVariantsResponse {

    private List<PpsrEpmMappingDTO> ProductVariants;

    public EPMProductVariantsResponse(List<PpsrEpmMappingDTO> productVariants) {
        ProductVariants = productVariants;
    }

    public List<PpsrEpmMappingDTO> getProductVariants() {
        return ProductVariants;
    }
}
