package com.bt.ppsr.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class ProductFriendlyNameSelectableValuesDTO {

    private String productFriendlyName;
    private Integer productFriendlyId;

    public ProductFriendlyNameSelectableValuesDTO(String productFriendlyName, Integer productFriendlyId) {
        this.productFriendlyName = productFriendlyName;
        this.productFriendlyId = productFriendlyId;
    }

    public String getProductFriendlyName() {
        return productFriendlyName;
    }

    public Integer getProductFriendlyId() {
        return productFriendlyId;
    }
}
