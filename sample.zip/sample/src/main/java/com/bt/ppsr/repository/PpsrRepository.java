package com.bt.ppsr.repository;

import com.bt.ppsr.model.*;
import com.bt.ppsr.repository.entity.PpsrEpmMappingEntity;

import java.util.List;

public interface PpsrRepository {
    List<ProductTypeSelectableValuesDTO> getProductTypes();

    List<ProductNameSelectableValuesDTO> getProductNames(Integer selectedProductType, String searchString);

    List<ProductFriendlyNameSelectableValuesDTO> getProductFriendlyNames(Integer prodKey);

    List<PriceLineSelectableValuesDTO> getPriceLineNames(Integer prodFriendlyId);

    List<String> getChargeTypes();

    void saveEpmMappingDetails(PpsrEpmMappingEntity entity);

    void savePortfolioFormDetails(PortfolioForm portfolioForm);

}
