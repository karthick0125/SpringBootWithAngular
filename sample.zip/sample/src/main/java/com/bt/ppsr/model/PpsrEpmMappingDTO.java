package com.bt.ppsr.model;

import com.bt.ppsr.repository.entity.PpsrEpmMappingEntity;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class PpsrEpmMappingDTO {

    private String pref;

    private String productFamilyName;

    private String productGroupName;

    private String productName;

    private String productVariantName;

    private String prCode;

    private Integer productFriendlyId;


    public PpsrEpmMappingDTO(String pref, String productFamilyName, String productGroupName, String productName,
                             String productVariantName, String prCode, Integer productFriendlyId) {
        this.pref = pref;
        this.productFamilyName = productFamilyName;
        this.productGroupName = productGroupName;
        this.productName = productName;
        this.productVariantName = productVariantName;
        this.prCode = prCode;
        this.productFriendlyId = productFriendlyId;
    }

    public String getPref() {
        return pref;
    }

    public String getProductFamilyName() {
        return productFamilyName;
    }

    public String getProductGroupName() {
        return productGroupName;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductVariantName() {
        return productVariantName;
    }

    public String getPrCode() {
        return prCode;
    }

    public Integer getProductFriendlyId() {
        return productFriendlyId;
    }

    public PpsrEpmMappingEntity toEntity() {
        return new PpsrEpmMappingEntity(getPref(), getProductFamilyName(), getProductGroupName(), getProductName(), getProductVariantName(), getPrCode(), getProductFriendlyId());
    }
}
