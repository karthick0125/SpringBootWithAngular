package com.bt.ppsr.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class PriceLineSelectableValuesDTO {

    private String priceLineName;
    private Integer plnDescId;

    public PriceLineSelectableValuesDTO(String priceLineName, Integer plnDescId) {
        this.priceLineName = priceLineName;
        this.plnDescId = plnDescId;
    }

    public String getPriceLineName() {
        return priceLineName;
    }

    public Integer getPlnDescId() {
        return plnDescId;
    }
}
