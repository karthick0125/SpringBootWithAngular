package com.bt.ppsr.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan("com.bt")
@EntityScan("com.bt.ppsr.repository")
public class PpsrProductPortfolioApplication {

    public static void main(String[] args) {
        SpringApplication.run(PpsrProductPortfolioApplication.class, args);
    }
}
