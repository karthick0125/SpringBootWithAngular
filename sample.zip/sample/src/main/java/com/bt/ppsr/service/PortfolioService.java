package com.bt.ppsr.service;

import com.bt.ppsr.model.*;

import java.util.List;

public interface PortfolioService {

    List<ProductTypeSelectableValuesDTO> getProductTypes();

    List<ProductNameSelectableValuesDTO> getProductNames(Integer selectedProductType, String searchString);

    List<ProductFriendlyNameSelectableValuesDTO> getProductFriendlyNames(Integer prodKey);

    List<PriceLineSelectableValuesDTO> getPriceLineNames(Integer prodFriendlyId);

    List<String> getChargeTypes();

    PpsrEpmMappingDTO fetchEpmMappingDetails(String pRefIds);

    void savePortfolioFormDetails(PortfolioForm portfolioForm);
}
