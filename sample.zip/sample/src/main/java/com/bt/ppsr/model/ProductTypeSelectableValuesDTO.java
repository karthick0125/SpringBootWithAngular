package com.bt.ppsr.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class ProductTypeSelectableValuesDTO {

    private String productTypeName;
    private Integer productType;

    public ProductTypeSelectableValuesDTO(String productTypeName, Integer productType) {
        this.productTypeName = productTypeName;
        this.productType = productType;
    }
}
