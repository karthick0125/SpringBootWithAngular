package com.bt.ppsr.model;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@ToString
public class ProductNameSelectableValuesDTO {

    private Integer prodKey;
    private String productName;

    public ProductNameSelectableValuesDTO(Integer prodKey, String productName) {
        this.prodKey = prodKey;
        this.productName = productName;
    }

    public Integer getProdKey() {
        return prodKey;
    }

    public String getProductName() {
        return productName;
    }
}
