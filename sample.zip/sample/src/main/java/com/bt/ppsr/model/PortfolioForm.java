package com.bt.ppsr.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PortfolioForm {
    private String chargeType;
    private String productCode;
    private Integer productType;
    private String projectCode;
    private PpsrEpmMappingDTO ppsrEpmMapping;
    private ProductFriendlyNameSelectableValuesDTO productFriendlyNameSelectableValue;
    private ProductNameSelectableValuesDTO productNameSelectableValue;
    private PriceLineSelectableValuesDTO priceLineSelectableValue;

    public PortfolioForm(String chargeType, String productCode, Integer productType, String projectCode, PpsrEpmMappingDTO ppsrEpmMapping, ProductFriendlyNameSelectableValuesDTO productFriendlyNameSelectableValue, ProductNameSelectableValuesDTO productNameSelectableValue, PriceLineSelectableValuesDTO priceLineSelectableValue) {
        this.chargeType = chargeType;
        this.productCode = productCode;
        this.productType = productType;
        this.projectCode = projectCode;
        this.ppsrEpmMapping = ppsrEpmMapping;
        this.productFriendlyNameSelectableValue = productFriendlyNameSelectableValue;
        this.productNameSelectableValue = productNameSelectableValue;
        this.priceLineSelectableValue = priceLineSelectableValue;
    }

    public String getChargeType() {
        return chargeType;
    }

    public String getProductCode() {
        return productCode;
    }

    public Integer getProductType() {
        return productType;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public PpsrEpmMappingDTO getPpsrEpmMapping() {
        return ppsrEpmMapping;
    }

    public ProductFriendlyNameSelectableValuesDTO getProductFriendlyNameSelectableValue() {
        return productFriendlyNameSelectableValue;
    }

    public ProductNameSelectableValuesDTO getProductNameSelectableValue() {
        return productNameSelectableValue;
    }

    public PriceLineSelectableValuesDTO getPriceLineSelectableValue() {
        return priceLineSelectableValue;
    }
}
