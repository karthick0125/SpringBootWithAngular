package com.bt.ppsr.repository.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "ppsr_products")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PpsrProductsEntity {


    @Id
    @Column(name = "PRODKEY")
    private Long prodKey;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "PRODUCT_SUPPLIERCODE")
    private String productSupplierCode;

    @Column(name = "PRODUCT_DESC")
    private String producDesc;

    @Column(name = "PRODUCT_TYPE")
    private Integer productType;

    @Column(name = "DELETED_FLAG")
    private String deletedFlag;

    @Column(name = "LAST_UPDATED_DATE")
    private String lastUpdatedDate;


}
