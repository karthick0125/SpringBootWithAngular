package com.bt.ppsr.repository.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PPSR_EPM_MAPPING")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PpsrEpmMappingEntity {

    @Id
    @Column(name = "PREF")
    private String pref;

    @Column(name = "PROD_FAMILY_NAME")
    private String productFamilyName;

    @Column(name = "PROD_GROUP_NAME")
    private String productGroupName;

    @Column(name = "PROD_NAME")
    private String productName;

    @Column(name = "PROD_VARIANT_NAME")
    private String productVariantName;

    @Column(name = "PR_CODE")
    private String prCode;

    @Column(name = "PROD_FRIENDLY_ID")
    private Integer productFriendlyId;


    public PpsrEpmMappingEntity(String pref, String productFamilyName, String productGroupName, String productName,
                                String productVariantName, String prCode, Integer productFriendlyId) {
        this.pref = pref;
        this.productFamilyName = productFamilyName;
        this.productGroupName = productGroupName;
        this.productName = productName;
        this.productVariantName = productVariantName;
        this.prCode = prCode;
        this.productFriendlyId = productFriendlyId;
    }
}
