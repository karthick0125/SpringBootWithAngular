package com.bt.ppsr.client;

import com.bt.ppsr.model.EPMProductVariantsResponse;
import com.bt.ppsr.model.PpsrEpmMappingDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@Component
public class EpmClient {

    @Value("${epm.endpoint.url}")
    private String endpointURL;

    public List<PpsrEpmMappingDTO> getEpmDetails(String pRefIds) {

        List<PpsrEpmMappingDTO> ppsrEpmMappingDTOS = new ArrayList<>();
        try {

/*          This commented code used to replace the path params
            Map<String, String> params = new HashMap<String, String>();
            params.put("id", "1234");
            URI uri = UriComponentsBuilder.fromUriString(endpointURL)
                    .buildAndExpand(params)
                    .toUri();*/
            URI uri = UriComponentsBuilder
                    .fromUriString(endpointURL)
                    .queryParam("pRefIds", pRefIds)
                    .build()
                    .toUri();

            ObjectMapper mapper = new ObjectMapper();
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Accept", MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);


            RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
            ResponseEntity<String> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, httpEntity, String.class);

            System.out.println(responseEntity.getBody());

           /* ppsrEpmMappingDTOS = mapper.readValue(responseEntity.getBody(), new TypeReference<List<PpsrEpmMappingDTO>>() {
            }); */

            EPMProductVariantsResponse response = mapper.readValue(responseEntity.getBody(), EPMProductVariantsResponse.class);
            ppsrEpmMappingDTOS = response.getProductVariants();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ppsrEpmMappingDTOS;
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        int timeout = 5000;
        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(timeout)
                .setConnectionRequestTimeout(timeout)
                .setSocketTimeout(timeout)
                .build();
        CloseableHttpClient client = HttpClientBuilder
                .create()
                .setDefaultRequestConfig(config)
                .build();
        return new HttpComponentsClientHttpRequestFactory(client);
    }
}
