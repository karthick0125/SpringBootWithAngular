package com.bt.ppsr.controller;

import com.bt.ppsr.model.*;
import com.bt.ppsr.service.PortfolioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ppsr/ppsr-portfolio")
public class PPSRPortfolioController {

    @Autowired
    private PortfolioServiceImpl portfolioService;


    @GetMapping(path = "/productTypeSelectableValues", produces = "application/json")
    public ResponseEntity<List<ProductTypeSelectableValuesDTO>> getProductTypes() {

        List<ProductTypeSelectableValuesDTO> productTypes = portfolioService.getProductTypes();

        return new ResponseEntity<>(productTypes, HttpStatus.OK);
    }

    @GetMapping(path = "/productNameSelectableValues", produces = "application/json")
    public ResponseEntity<List<ProductNameSelectableValuesDTO>> getProductNames(@RequestParam("productType") String selectedProductType,
                                                                                @RequestParam("searchContent") String searchContent) {

        List<ProductNameSelectableValuesDTO> productNames = portfolioService.getProductNames(Integer.valueOf(selectedProductType), searchContent);

        return new ResponseEntity<>(productNames, HttpStatus.OK);
    }

    @GetMapping(path = "/productFriendlyNameSelectableValues", produces = "application/json")
    public ResponseEntity<List<ProductFriendlyNameSelectableValuesDTO>> getProductFriendlyNames(@RequestParam("prodKey") String prodKey) {

        List<ProductFriendlyNameSelectableValuesDTO> productFriendlyNames = portfolioService.getProductFriendlyNames(Integer.valueOf(prodKey));
        return new ResponseEntity<>(productFriendlyNames, HttpStatus.OK);
    }

    @GetMapping(path = "/pricelineNameSelectableValues", produces = "application/json")
    public ResponseEntity<List<PriceLineSelectableValuesDTO>> getPriceLineNames(@RequestParam("prodFriendlyId") String prodFriendlyId) {

        List<PriceLineSelectableValuesDTO> priceLineNames = portfolioService.getPriceLineNames(Integer.valueOf(prodFriendlyId));
        return new ResponseEntity<>(priceLineNames, HttpStatus.OK);
    }

    @GetMapping(path = "/chargeTypeSelectableValues", produces = "application/json")
    public ResponseEntity<List<String>> getChargeTypes() {

        List<String> chargeTypes = portfolioService.getChargeTypes();
        return new ResponseEntity<>(chargeTypes, HttpStatus.OK);
    }

    @GetMapping(path = "/fetchEpmMappingDetails", produces = "application/json")
    public ResponseEntity<PpsrEpmMappingDTO> fetchEpmMappingDetails(@RequestParam("pRefIds") String pRefIds) {

        PpsrEpmMappingDTO ppsrEpmMappingDTO = portfolioService.fetchEpmMappingDetails(pRefIds);
        return new ResponseEntity<>(ppsrEpmMappingDTO, HttpStatus.OK);
    }

    @PostMapping(path = "/saveFormDetails")
    public String saveFormDetails(@RequestBody PortfolioForm portfolioForm) {

        portfolioService.savePortfolioFormDetails(portfolioForm);
        return "Form Details are updated successfully";
    }

}
