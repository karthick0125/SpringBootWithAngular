package com.bt.ppsr.repository;

import com.bt.ppsr.model.*;
import com.bt.ppsr.repository.entity.PpsrEpmMappingEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static com.bt.ppsr.model.SpConstants.*;

@Repository
@Transactional
public class PpsrRepositoryImpl implements PpsrRepository {

    @PersistenceContext
    @SuppressWarnings("unused")
    private EntityManager entityManager;


    @Override
    public List<ProductTypeSelectableValuesDTO> getProductTypes() {
        try {
            List<ProductTypeSelectableValuesDTO> productTypeSelectableValuesDTOS = new ArrayList<>();
            String getProductTypeSql = "select distinct case when product_type=1\n" +
                    "then 'CPE'\n" +
                    "when product_type=2\n" +
                    "then 'NS'\n" +
                    "\n" +
                    "when product_type=3\n" +
                    "then 'VAS'\n" +
                    "\n" +
                    "when product_type=4\n" +
                    "then 'CPE ITEM'\n" +
                    "\n" +
                    "when product_type=5\n" +
                    "then 'PACKAGES'\n" +
                    "\n" +
                    "when product_type=6\n" +
                    "then 'SOFTWARE'\n" +
                    "end t,product_type\n" +
                    "from ppsr_products";

            Query query = entityManager.createNativeQuery(getProductTypeSql);

            List productTypes = query.getResultList();

            for (Object productTypeObj : productTypes) {
                Object[] columns = (Object[]) productTypeObj;
                String productTypeName = asString(columns[0]);
                Integer productType = asInteger(columns[1]);
                productTypeSelectableValuesDTOS.add(new ProductTypeSelectableValuesDTO(productTypeName, productType));

            }

            return productTypeSelectableValuesDTOS;
        } finally {
            entityManager.close();
        }
    }

    @Override
    public List<ProductNameSelectableValuesDTO> getProductNames(Integer selectedProductType, String searchString) {
        try {
            List<ProductNameSelectableValuesDTO> productNameSelectableValuesDTOS = new ArrayList<>();

            String productNameSql = "SELECT PRODKEY,PRODUCT_NAME FROM PPSR_PRODUCTS WHERE DELETED_FLAG is NULL " +
                    "AND PRODUCT_TYPE=:selectedProductType AND UPPER(PRODUCT_NAME) LIKE UPPER(:searchString)";

            Query query = entityManager.createNativeQuery(productNameSql);

            query.setParameter("selectedProductType", selectedProductType);
            query.setParameter("searchString", "%" + searchString + "%");

            List productNames = query.getResultList();

            for (Object object : productNames) {
                Object[] columns = (Object[]) object;
                Integer prodKey = asInteger(columns[0]);
                String productName = asString(columns[1]);
                productNameSelectableValuesDTOS.add(new ProductNameSelectableValuesDTO(prodKey, productName));

            }

            return productNameSelectableValuesDTOS;
        } finally {
            entityManager.close();
        }

    }

    @Override
    public List<ProductFriendlyNameSelectableValuesDTO> getProductFriendlyNames(Integer selectedProdKey) {
        try {
            List<ProductFriendlyNameSelectableValuesDTO> productFriendlyNameSelectableValuesDTOs = new ArrayList<>();

            String productFriendlyNameSql = "select product_friendly_name,prod_friendly_id from ppsr_product_owner where prodkey=:selectedProdKey";

            Query query = entityManager.createNativeQuery(productFriendlyNameSql);

            query.setParameter("selectedProdKey", selectedProdKey);

            List productFriendlyNames = query.getResultList();

            for (Object object : productFriendlyNames) {
                Object[] columns = (Object[]) object;
                String productFriendlyName = asString(columns[0]);
                Integer prodFriendlyId = asInteger(columns[1]);

                productFriendlyNameSelectableValuesDTOs.add(new ProductFriendlyNameSelectableValuesDTO(productFriendlyName, prodFriendlyId));

            }

            return productFriendlyNameSelectableValuesDTOs;
        } finally {
            entityManager.close();
        }
    }

    @Override
    public List<PriceLineSelectableValuesDTO> getPriceLineNames(Integer prodFriendlyId) {
        try {
            List<PriceLineSelectableValuesDTO> priceLineSelectableValuesDTOS = new ArrayList<>();

            String priceLineNamesSql = "select PLN_DESC_ID,pln_priceline_name from ppsr_product_price_line where prod_friendly_id=:prodFriendlyId";

            Query query = entityManager.createNativeQuery(priceLineNamesSql);

            query.setParameter("prodFriendlyId", prodFriendlyId);

            List priceLineNames = query.getResultList();

            for (Object object : priceLineNames) {
                Object[] columns = (Object[]) object;
                Integer plnDescId = asInteger(columns[0]);
                String priceLineName = asString(columns[1]);

                priceLineSelectableValuesDTOS.add(new PriceLineSelectableValuesDTO(priceLineName, plnDescId));

            }

            return priceLineSelectableValuesDTOS;

        } finally {
            entityManager.close();
        }
    }

    @Override
    public List<String> getChargeTypes() {
        try {
            List<String> chargeTypes = new ArrayList<>();

            String chargeTypeSql = "select distinct charge_type from PPSR_REV_CHARGE_MAPPING";

            Query query = entityManager.createNativeQuery(chargeTypeSql);

            List resultList = query.getResultList();
            for (Object object : resultList) {
                chargeTypes.add(asString(object));
            }
            return chargeTypes;
        } finally {
            entityManager.close();
        }
    }

    @Override
    public void saveEpmMappingDetails(PpsrEpmMappingEntity entity) {

        try {
            entityManager.merge(entity);
        } finally {
            entityManager.close();
        }
    }

    @Override
    public void savePortfolioFormDetails(PortfolioForm portfolioForm) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PPSR_EPM_MAPPING_SP");
        registerSpParams(query);
        setSpParams(query,portfolioForm);
        query.execute();

        List<Object[]> postComments = query.getResultList();
        System.out.println(postComments);
    }

    private void setSpParams(StoredProcedureQuery query,PortfolioForm portfolioForm) {
        Integer productFriendlyId = portfolioForm.getProductFriendlyNameSelectableValue().getProductFriendlyId();
        PpsrEpmMappingDTO ppsrEpmMapping = portfolioForm.getPpsrEpmMapping();
        String productName = portfolioForm.getProductNameSelectableValue().getProductName();
        PriceLineSelectableValuesDTO priceLineSelectableValue = portfolioForm.getPriceLineSelectableValue();

        query.setParameter(PIN_PRODFRIENDLYID.name(), productFriendlyId)
                .setParameter(PIN_CHARGETYPE.name(), portfolioForm.getChargeType())
                .setParameter(PIN_PRODUCTFAMILYNAME.name(), ppsrEpmMapping.getProductFamilyName())
                .setParameter(PIN_PRODUCTGROUPNAME.name(), ppsrEpmMapping.getProductGroupName())
                .setParameter(PIN_PRODUCTNAME.name(), productName)
                .setParameter(PIN_PRODUCTVARIANTNAME.name(), ppsrEpmMapping.getProductVariantName())
                .setParameter(PIN_PRCODE.name(), portfolioForm.getProductCode())
                .setParameter(PIN_PRODUCTTYPE.name(), portfolioForm.getProductType())
                .setParameter(PIN_PREF.name(), ppsrEpmMapping.getPref())
                .setParameter(PIN_SUPPLIER.name(), priceLineSelectableValue.getPriceLineName())  //need confirmation
                .setParameter(PIN_CPE_REVENUE_CODE.name(), ppsrEpmMapping.getProductVariantName()) //need confirmation
                .setParameter(PIN_PLN_DESC_ID.name(), priceLineSelectableValue.getPlnDescId()); //need confirmation
    }

    private void registerSpParams(StoredProcedureQuery query) {
        query.registerStoredProcedureParameter(PIN_PRODFRIENDLYID.name(), Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_CHARGETYPE.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRODUCTFAMILYNAME.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRODUCTGROUPNAME.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRODUCTNAME.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRODUCTVARIANTNAME.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRCODE.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PRODUCTTYPE.name(), Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PREF.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_SUPPLIER.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_CPE_REVENUE_CODE.name(), String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(PIN_PLN_DESC_ID.name(), Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter(POV_ERROR_CODE.name(), String.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(POV_ERROR_MESSAGE.name(), String.class, ParameterMode.OUT);
    }

    private String asString(Object column) {
        if (null != column) {
            return String.valueOf(column);
        }
        return "";
    }

    private Integer asInteger(Object column) {
        if (null != column) {
            return Integer.valueOf(String.valueOf(column));
        }
        return null;
    }


}
